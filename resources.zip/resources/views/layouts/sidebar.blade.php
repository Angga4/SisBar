<body>
<div class="wrapper" id="appWrapper">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidenav-main">
        <div class="d-flex justify-content-between align-items-center p-3">
            <h5 class="m-0 fw-bold text-primary">SIPBAR</h5>
            <button id="closeSidebar" class="btn btn-sm btn-icon">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <hr class="horizontal dark mt-0">

        <div class="sidebar-content">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs(auth()->user()->role . '.dashboard') ? 'active' : '' }}"
                       href="{{ route(auth()->user()->role . '.dashboard') }}">
                        <i class="fas fa-home me-2"></i> Dashboard
                    </a>
                </li>

                @if(auth()->user()->role === 'admin')
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('barang.*') ? 'active' : '' }}"
                           href="{{ route('barang.index') }}">
                            <i class="fas fa-box me-2"></i> Manajemen Barang
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('guru.*') ? 'active' : '' }}"
                           href="{{ route('guru.index') }}">
                            <i class="fas fa-user me-2"></i> Manajemen Guru
                        </a>
                    </li>
                @else
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('guru.peminjaman.*') ? 'active' : '' }}"
                           href="{{ route('guru.peminjaman.index') }}">
                            <i class="fas fa-hand-holding me-2"></i> Peminjaman
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('guru.pengembalian.*') ? 'active' : '' }}"
                           href="{{ route('guru.pengembalian.index') }}">
                            <i class="fas fa-undo-alt me-2"></i> Pengembalian
                        </a>
                    </li>
                @endif

                <li class="nav-item mt-3">
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-danger w-100">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    </aside>

    <!-- Konten utama -->
    <main class="main">
        <!-- Tombol toggle -->
        <button class="toggle-btn" id="openSidebar"><i class="fas fa-bars"></i></button>

        <!-- Navbar (jika ada) -->
        @include('layouts.navbar')

        <!-- Konten dinamis -->
        @yield('content')
    </main>
</div>

<!-- Mobile sidebar toggle button -->
<button id="openSidebar" class="toggle-btn d-md-none">
    <i class="fas fa-bars"></i>
</button>

<!-- JS: Toggle Sidebar -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
    const wrapper = document.getElementById('wrapper');
    const sidebar = document.querySelector('.sidebar');
    const openBtn = document.getElementById('openSidebar');
    const closeBtn = document.getElementById('closeSidebar');

    if (openBtn) {
        openBtn.addEventListener('click', () => {
            sidebar.classList.add('show');
            wrapper.classList.add('with-sidebar');
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            sidebar.classList.remove('show');
            wrapper.classList.remove('with-sidebar');
        });
    }

    // Tutup sidebar secara otomatis di layar kecil
    function handleResize() {
        if (window.innerWidth <= 768) {
            sidebar.classList.remove('show');
            wrapper.classList.remove('with-sidebar');
        }
    }

    window.addEventListener('resize', handleResize);
    handleResize();
});
</script>
</body>
